#include "Figuras.h"

Triangulo::Triangulo(){
    nome = "Triangulo";
}
float Triangulo::calcularArea(float b, float h){
    return (b*h)/2.0;
}
////////////////////////////////////////////////////////
Circulo::Circulo(){
    nome = "Circulo";
}
float Circulo::calcularArea(float r){
    return PI*r*r;
}
////////////////////////////////////////////////////////
Quadrado::Quadrado(){
    nome = "Quadrado";
}
float Quadrado::calcularArea(float l){
    return l*l;
}