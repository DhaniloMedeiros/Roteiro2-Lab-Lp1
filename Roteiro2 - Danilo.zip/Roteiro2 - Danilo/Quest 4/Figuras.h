#include "FiguraGeometrica.h"
#include <iostream>
#define PI 3.14

class Triangulo : public FiguraGeometrica
{
public:
    Triangulo();
    float calcularArea(float b, float h);
};

class Circulo : public FiguraGeometrica
{
public:
    Circulo();
    float calcularArea(float r);
};

class Quadrado : public FiguraGeometrica
{
public:
    Quadrado();
    float calcularArea(float l);
};


