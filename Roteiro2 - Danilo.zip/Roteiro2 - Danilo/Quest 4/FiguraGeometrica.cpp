#include "FiguraGeometrica.h"

FiguraGeometrica::FiguraGeometrica(){
    nome = "NULL";
}
float FiguraGeometrica::calcularArea(){
    return 0;
}
std::string FiguraGeometrica::getNome(){
    return nome;
}