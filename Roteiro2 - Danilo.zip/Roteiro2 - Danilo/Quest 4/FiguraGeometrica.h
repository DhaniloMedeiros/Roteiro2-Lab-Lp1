#pragma once
#include <iostream>

class FiguraGeometrica
{
protected:
    std::string nome;
public:
    FiguraGeometrica();
    float calcularArea();
    std::string getNome();
};
