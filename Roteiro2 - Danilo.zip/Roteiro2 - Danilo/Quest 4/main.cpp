#include "Figuras.h"
#include <iostream>

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif

}

void exibeMenu(){
    puts("\n~~~~~MENU~~~~~");
    puts("   1 - Triangulo");
    puts("   2 - Quadrado");
    puts("   3 - Circulo");
    puts("   4 - Finalizar o programa");

    std::cout << "Digite a opcao desejada:";
}

int main(){
    Triangulo triangulo;
    Quadrado quadrado;
    Circulo circulo;
    bool loop = true;

    while(loop){
        float a, b;
        int menu;
        limpaTela();
        exibeMenu();
        std::cin >> menu;
        getchar();

        switch (menu)
        {
        case 1:
            limpaTela();
            std::cout << "Informe o valor da base do triangulo: ";
            std::cin >> a;
            getchar();
            std::cout << "Informe a valor da altura do triangulo: ";
            std::cin >> b;
            getchar();
            std::cout << "O seu " << triangulo.getNome() << " possui area = " << triangulo.calcularArea(a, b) << std::endl;
            std::cout << "\nAperte ENTER.";
            getchar();
            break;
        case 2:
            limpaTela();
            std::cout << "Informe o valor do lado do quadrado: ";
            std::cin >> a;
            getchar();
            std::cout << "O seu " << quadrado.getNome() << " possui area = " << quadrado.calcularArea(a) << std::endl;
            std::cout << "\nAperte ENTER.";
            getchar();
            break;
        case 3:
            limpaTela();
            std::cout << "Informe o valor do raio do circulo: ";
            std::cin >> a;
            getchar();
            std::cout << "O seu " << circulo.getNome() << " possui area = " << circulo.calcularArea(a) << std::endl;
            std::cout << "\nAperte ENTER.";
            getchar();
            break;
        case 4:
            limpaTela();
            break;
        default:
            limpaTela();
            std::cout << "Erro, aperte ENTER."; 
            getchar();
            
            break;
        }
    }

    std::cout << "Fim" << std::endl;
    
    return 0;
}