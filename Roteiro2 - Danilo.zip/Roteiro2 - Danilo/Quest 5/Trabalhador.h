#pragma once
#include <iostream>

class Trabalhador
{
protected:
    std::string nome;
    float salario;
public:
    Trabalhador();
    void setNome(std::string n);
    float getSalario();
    std::string getNome();
    void setSalario(float sl);
};
