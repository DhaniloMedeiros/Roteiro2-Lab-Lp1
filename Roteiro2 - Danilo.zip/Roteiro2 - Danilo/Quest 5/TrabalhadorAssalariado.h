#pragma once
#include "Trabalhador.h"

class TrabalhadorAssalariado : public Trabalhador
{
public:
    TrabalhadorAssalariado(std::string n, float sl);
};
