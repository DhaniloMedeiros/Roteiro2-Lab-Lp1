#include "TrabalhadorPorHora.h"

TrabalhadorPorHora::TrabalhadorPorHora(){
    valorDaHora = 0;
}
TrabalhadorPorHora::TrabalhadorPorHora(float vl, std::string n){
    valorDaHora = vl;
    nome = n;
}
float TrabalhadorPorHora::calcularPagamentoSemanal(int horasSemanais){
    int horasExcedentes;
    if(horasSemanais <= 40){
        salario = horasSemanais * valorDaHora * 4;//estimando salario mensal
        return horasSemanais * valorDaHora;
    }
    else{
        horasExcedentes = horasSemanais - 40;
        salario = (40 * valorDaHora + horasExcedentes * (1.5 * valorDaHora)) * 4;//estimando salario mensal
        return (40 * valorDaHora + horasExcedentes * (1.5 * valorDaHora));
    }
    return salario;
}
void TrabalhadorPorHora::setValorDaHora(float vl){
    valorDaHora = vl;
}

float TrabalhadorPorHora::getValorDaHora(){
    return valorDaHora;
}