#include "Trabalhador.h"

Trabalhador::Trabalhador(){
    nome = "NULL";
    salario = 0;
}
float Trabalhador::getSalario(){
    return salario;
}
std::string Trabalhador::getNome(){
    return nome;
}
void Trabalhador::setSalario(float sl){
    salario = sl;
}
void Trabalhador::setNome(std::string n){
    nome = n;
}