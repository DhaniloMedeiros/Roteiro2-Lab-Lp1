#include "TrabalhadorAssalariado.h"
#include "TrabalhadorPorHora.h"

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif

}

void exibeMenu(){
    puts("\n~~~~~MENU~~~~~");
    puts("   1 - Assalariado1");
    puts("   2 - PorHora1");    
    puts("   3 - Finalizar o programa");

    std::cout << "Digite a opcao desejada: ";
}

void menuAssalariado(){
    puts("\n~~~~~MENU DO ASSALARIADO~~~~~");
    puts("   1 - Set atributos");
    puts("   2 - Get atributos");    

    std::cout << "Digite a opcao desejada: ";
}

void menuSetAssalariado(){
    puts("\n~~~~~SET~~~~~");
    puts("   1 - Set nome");
    puts("   2 - Set salario");    

    std::cout << "Digite a opcao desejada: ";
}

void menuGetAssalariado(){
    puts("\n~~~~~GET~~~~~");
    puts("   1 - Get nome");
    puts("   2 - Get salario");    

    std::cout << "Digite a opcao desejada: ";
}

void menuPorHora(){
    puts("\n~~~~~MENU DO POR HORA~~~~~");
    puts("   1 - Set atributos");
    puts("   2 - Get atributos");
    puts("   3 - Calcular pagamento semanal");    

    std::cout << "Digite a opcao desejada: ";
}

void menuSetPorHora(){
    puts("\n~~~~~SET~~~~~");
    puts("   1 - Set nome");
    puts("   2 - Set valor da hora");    

    std::cout << "Digite a opcao desejada: ";
}

void menuGetPorHora(){
    puts("\n~~~~~GET~~~~~");
    puts("   1 - Get nome");
    puts("   2 - Get valor da hora");    

    std::cout << "Digite a opcao desejada: ";
}

void printTrabalhadorAssalariado(TrabalhadorAssalariado &Trab){
    std::cout << "Nome: " << Trab.getNome() << std::endl;;
    std::cout << "Salario: R$" << Trab.getSalario() << std::endl;
}

void printTrabalhadorPorHora(TrabalhadorPorHora &Trab){
    std::cout << "Nome: " << Trab.getNome() << std::endl;;
    std::cout << "Valor da hora: R$" << Trab.getValorDaHora() << std::endl;
}

int main(){
    TrabalhadorAssalariado assalariado1 = TrabalhadorAssalariado("Chico", 8000);
    TrabalhadorPorHora porHora1 = TrabalhadorPorHora(50, "Henrique");
    bool loop = true;

    limpaTela();
    std::cout << "Trabalhador assalariado1:" << std::endl;
    printTrabalhadorAssalariado(assalariado1);
    std::cout << "\nTrabalhador por hora1:" << std::endl;
    printTrabalhadorPorHora(porHora1);
    std::cout << "\n Aperte ENTER.";
    getchar();

    while(loop)
    {
        int menu, hr;
        float sl;
        std::string str;
        limpaTela();
        exibeMenu();
        std::cin >> menu;
        getchar();
        switch(menu)//MENU GERAL
        {
            case 1:
                limpaTela();
                menuAssalariado();
                std::cin >> menu;
                getchar();
                switch (menu)//MENU DO ASSALARIADO
                {
                    case 1:
                        limpaTela();
                        menuSetAssalariado();
                        std::cin >> menu;
                        getchar();
                        switch (menu)
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Digite o nome: ";
                                getline(std::cin, str);
                                assalariado1.setNome(str);
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Digite o salario: ";
                                std::cin >> sl;
                                getchar();
                                assalariado1.setSalario(sl);
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    case 2:
                        limpaTela();
                        menuGetAssalariado();
                        std::cin >> menu;
                        getchar();
                        switch(menu)
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Nome: " << assalariado1.getNome() << std::endl;
                                std::cout << "\n Aperte ENTER.";
                                getchar();
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Salario: " << assalariado1.getSalario() << std::endl;
                                std::cout << "\n Aperte ENTER.";
                                getchar();
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    default:
                        limpaTela();
                        std::cout << "Erro, aperte ENTER.";
                        getchar();
                        break;
                }
                break;
            case 2:
                limpaTela();
                menuPorHora();
                std::cin >> menu;
                getchar();
                switch (menu)//MENU DO POR HORA
                {
                    case 1:
                        limpaTela();
                        menuSetPorHora();
                        std::cin >> menu;
                        getchar();
                        switch (menu)
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Digite o nome: ";
                                getline(std::cin, str);
                                porHora1.setNome(str);
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Digite o valor da hora: ";
                                std::cin >> sl;
                                getchar();
                                porHora1.setValorDaHora(sl);
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    case 2:
                        limpaTela();
                        menuGetPorHora();
                        std::cin >> menu;
                        getchar();
                        switch(menu)
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Nome: " << porHora1.getNome() << std::endl;
                                std::cout << "\n Aperte ENTER.";
                                getchar();
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Valor da hora: " << porHora1.getValorDaHora() << std::endl;
                                std::cout << "\n Aperte ENTER.";
                                getchar();
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER.";
                                getchar();
                                break;
                        }
                        break;
                    case 3:
                        limpaTela();
                        std::cout << "Digite o numero de horas trabalhadas na semana: ";
                        std::cin >> hr;
                        getchar();
                        std::cout << "Salario semanal recebido eh de: R$" << porHora1.calcularPagamentoSemanal(hr) << std::endl;
                        std::cout << "A estimativa mensal eh de: R$" << porHora1.getSalario();
                        std::cout << "\n Aperte ENTER.";
                        getchar();
                        break;
                    default:
                        limpaTela();
                        std::cout << "Erro, aperte ENTER.";
                        getchar();
                        break;
                }
                break;
            case 3:
                limpaTela();
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Erro, aperte ENTER.";
                getchar();
                break;
        }
    }

    std::cout << "Trabalhador assalariado1:" << std::endl;
    printTrabalhadorAssalariado(assalariado1);
    std::cout << "\nTrabalhador por hora1:" << std::endl;
    printTrabalhadorPorHora(porHora1);

    std::cout << "\nFim do programa, e FELIZ NATAL!!!!\n" << std::endl;
    puts("⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⣀⣴⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⣄⠄⠄⠄⠄");
    puts("⠄⠄⠄⠄⠄⢀⣀⣀⡀⠄⠄⠄⡠⢲⣾⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣷⡀⠄⠄");
    puts("⠄⠄⠄⠔⣈⣀⠄⢔⡒⠳⡴⠊⠄⠸⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⡿⠿⣿⣿⣧⠄⠄");
    puts("⠄⢜⡴⢑⠖⠊⢐⣤⠞⣩⡇⠄⠄⠄⠙⢿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣿⣆⠄⠝⠛⠋⠐");
    puts("⢸⠏⣷⠈⠄⣱⠃⠄⢠⠃⠐⡀⠄⠄⠄⠄⠙⠻⢿⣿⣿⣿⣿⣿⣿⣿⡿⠛⠸⠄⠄⠄⠄");
    puts("⠈⣅⠞⢁⣿⢸⠘⡄⡆⠄⠄⠈⠢⡀⠄⠄⠄⠄⠄⠄⠉⠙⠛⠛⠛⠉⠉⡀⠄⠡⢀⠄⣀");
    puts("⠄⠙⡎⣹⢸⠄⠆⢘⠁⠄⠄⠄⢸⠈⠢⢄⡀⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠃⠄⠄⠄⠄⠄");
    puts("⠄⠄⠑⢿⠈⢆⠘⢼⠄⠄⠄⠄⠸⢐⢾⠄⡘⡏⠲⠆⠠⣤⢤⢤⡤⠄⣖⡇⠄⠄⠄⠄⠄");
    puts("⣴⣶⣿⣿⣣⣈⣢⣸⠄⠄⠄⠄⡾⣷⣾⣮⣤⡏⠁⠘⠊⢠⣷⣾⡛⡟⠈⠄⠄⠄⠄⠄⠄");
    puts("⣿⣿⣿⣿⣿⠉⠒⢽⠄⠄⠄⠄⡇⣿⣟⣿⡇⠄⠄⠄⠄⢸⣻⡿⡇⡇⠄⠄⠄⠄⠄⠄⠄");
    puts("⠻⣿⣿⣿⣿⣄⠰⢼⠄⠄⠄⡄⠁⢻⣍⣯⠃⠄⠄⠄⠄⠈⢿⣻⠃⠈⡆⡄⠄⠄⠄⠄⠄");
    puts("⠄⠙⠿⠿⠛⣿⣶⣤⡇⠄⠄⢣⠄⠄⠈⠄⢠⠂⠄⠁⠄⡀⠄⠄⣀⠔⢁⠃⠄⠄⠄⠄⠄");
    puts("⠄⠄⠄⠄⠄⣿⣿⣿⣿⣾⠢⣖⣶⣦⣤⣤⣬⣤⣤⣤⣴⣶⣶⡏⠠⢃⠌⠄⠄⠄⠄⠄⠄");
    puts("⠄⠄⠄⠄⠄⠿⠿⠟⠛⡹⠉⠛⠛⠿⠿⣿⣿⣿⣿⣿⡿⠂⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄⠄");
    puts("⠠⠤⠤⠄⠄⣀⠄⠄⠄⠑⠠⣤⣀⣀⣀⡘⣿⠿⠙⠻⡍⢀⡈⠂⠄⠄⠄⠄⠄⠄⠄⠄⠄");
    puts("⠄⠄⠄⠄⠄⠄⠑⠠⣠⣴⣾⣿⣿⣿⣿⣿⣿⣇⠉⠄⠻⣿⣷⣄⡀⠄⠄⠄⠄⠄⠄⠄⠄\n");
    return 0;
} 