#pragma once
#include "Trabalhador.h"

class TrabalhadorPorHora : public Trabalhador
{
private:
    float valorDaHora; 
public:
    TrabalhadorPorHora();
    TrabalhadorPorHora(float vl, std::string n);
    float calcularPagamentoSemanal(int horasSemanais);
    void setValorDaHora(float vl);
    float getValorDaHora();
};
