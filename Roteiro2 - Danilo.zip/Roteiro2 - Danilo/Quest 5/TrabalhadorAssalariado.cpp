#include "TrabalhadorAssalariado.h"

TrabalhadorAssalariado::TrabalhadorAssalariado(std::string n, float sl){
    nome = n;
    salario = sl;
}
