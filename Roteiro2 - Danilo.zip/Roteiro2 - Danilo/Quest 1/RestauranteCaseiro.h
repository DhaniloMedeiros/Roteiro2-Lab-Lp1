#pragma once
#include "MesaDeRestaurante.h"
#include <iostream>

class RestauranteCaseiro
{
private:
    std::string nome;
public:
    MesaDeRestaurante mesa[20];
    RestauranteCaseiro(std::string n);
    void adicionaAoPedido(int numMesa, Pedido p);
    float calculaTotalRestaurante();
    std::string getNome();
};