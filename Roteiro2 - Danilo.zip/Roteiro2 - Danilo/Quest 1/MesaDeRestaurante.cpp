#include <vector>
#include "MesaDeRestaurante.h"

    MesaDeRestaurante::MesaDeRestaurante(){
        numero = 0;
    }
    void MesaDeRestaurante::adicionaAoPedido(Pedido p){
        bool add = true;
        for(int i = 0; i < pedido.size(); i++){
            if(pedido[i].numero == p.numero){
                pedido[i].quantidade += p.quantidade;
                add = false;
            }
        }
        if(add)
            pedido.push_back(p);
    }
    void MesaDeRestaurante::zeraPedidos(){
        for(int i = 0; i < pedido.size(); i++)
            pedido[i].quantidade = 0;
    }
    float MesaDeRestaurante::calculaTotal(){
        float total = 0;
        for(int i = 0; i < pedido.size(); i++)
            total += pedido[i].preco * pedido[i].quantidade;
        return total;
    }