#include "Pedido.h"

Pedido::Pedido(){
    numero = 0;
    descricao = "NULL";
    quantidade = 0;
    preco = 0;
}