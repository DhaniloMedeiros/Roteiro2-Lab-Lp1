#pragma once
#include "Pedido.h"
#include <vector>
class MesaDeRestaurante
{
public:
    std::vector<Pedido> pedido;
    MesaDeRestaurante();
    void adicionaAoPedido(Pedido p);
    void zeraPedidos();
    float calculaTotal();
    int numero;
};

