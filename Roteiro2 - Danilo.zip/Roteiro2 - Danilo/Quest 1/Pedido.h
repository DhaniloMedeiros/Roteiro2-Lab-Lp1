#pragma once
#include <iostream>

class Pedido
{
public:
    int numero;
    std::string descricao;
    int quantidade;
    float preco;
    Pedido();
};

