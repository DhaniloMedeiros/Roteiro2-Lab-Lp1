#include "Funcionario.h"
#include "Consultor.h"
#include <iostream>

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void printFuncionario(Funcionario &fr){
    std::cout << "Nome: " << fr.getNome() <<  std::endl;
    std::cout << "Matricula: " << fr.getMatricula() <<  std::endl;
    std::cout << "Salario: R$" << fr.getSalario() <<  std::endl;
}
void printConsultor(Consultor &cr){
    std::cout << "Nome: " << cr.getNome() <<  std::endl;
    std::cout << "Matricula: " << cr.getMatricula() <<  std::endl;
    std::cout << "Salario: R$" << cr.getSalario() <<  std::endl;
}

void menuSet(){
    puts("\n~~~~~MENU SET~~~~~");
    puts("   1 - Set nome");
    puts("   2 - Set matricula");
    puts("   3 - Set salario");

    std::cout << "Digite a opcao desejada:";
}
void menuGet(){
    puts("\n~~~~~MENU GET~~~~~");
    puts("   1 - Get nome");
    puts("   2 - Get matricula");
    puts("   3 - Get salario");

    std::cout << "Digite a opcao desejada:";
}

void exibeMenu(){
    puts("\n~~~~~MENU~~~~~");
    puts("   1 - Funcionario 1");
    puts("   2 - Consultor 1");
    puts("   3 - Finalizar o programa");

    std::cout << "Digite a opcao desejada:";
}

void menuSetGet(){
    puts("\n~~~~~MENU~~~~~");
    puts("   1 - Set atributos");
    puts("   2 - Get atributos");

    std::cout << "Digite a opcao desejada:";
}

int main(){
    Funcionario funcionario1 = Funcionario();
    Consultor consultor1 = Consultor();
    bool loop = true;
    limpaTela();
    std::cout << "Funcionario1." << std::endl;
    printFuncionario(funcionario1);
    std::cout << "\nConsultor1." << std::endl;
    printConsultor(consultor1);
    
    std::cout<< "\nAperte ENTER.";
    getchar();

    while(loop){
        int menu;
        std::string str;
        float sal;
        limpaTela();
        exibeMenu();
        std::cin >> menu;
        getchar();
        switch(menu)//menu func e cons
        {
            case 1:
                limpaTela();
                menuSetGet();
                std::cin >> menu;
                getchar();
                switch(menu)//menu set e get FUNC
                {
                    case 1:
                        limpaTela();
                        menuSet();
                        std::cin >> menu;
                        getchar();
                        switch (menu)//menu set FUNC
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Digite o nome: ";
                                getline(std::cin, str);
                                funcionario1.setNome(str);
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Digite a matricula: ";
                                getline(std::cin, str);
                                funcionario1.setMatricula(str);
                                break;
                            case 3:
                                limpaTela();
                                std::cout << "Digite o salario: ";
                                std::cin >> sal;
                                getchar();
                                funcionario1.setSalario(sal);
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER."; 
                                getchar();
                                break;
                        }
                        break;
                    case 2:
                        limpaTela();
                        menuGet();
                        std::cin >> menu;
                        getchar();
                        switch (menu)//menu get FUNC
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Nome: " << funcionario1.getNome() << std::endl;
                                std::cout << "Aperte ENTER.";
                                getchar();
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Matricula: " << funcionario1.getMatricula() << std::endl;
                                std::cout << "Aperte ENTER.";
                                getchar();
                                break;
                            case 3:
                                limpaTela();
                                std::cout << "Salario: R$ " << funcionario1.getSalario() << std::endl;
                                std::cout << "Aperte ENTER.";
                                getchar();
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER."; 
                                getchar();
                                break;
                        }
                        break;
                    default:
                        limpaTela();
                        std::cout << "Erro, aperte ENTER."; 
                        getchar();
                        break;
                }
                break;
            case 2:
                limpaTela();
                menuSetGet();
                std::cin >> menu;
                getchar();
                switch(menu)//menu set e get CONS
                {
                    case 1:
                        limpaTela();
                        menuSet();
                        std::cin >> menu;
                        getchar();
                        switch (menu)//menu set CONS
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Digite o nome: ";
                                getline(std::cin, str);
                                consultor1.setNome(str);
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Digite a matricula: ";
                                getline(std::cin, str);
                                consultor1.setMatricula(str);
                                break;
                            case 3:
                                limpaTela();
                                std::cout << "Digite o salario base: ";
                                std::cin >> sal;
                                getchar();
                                consultor1.setSalario(sal);
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER."; 
                                getchar();
                                break;
                        }
                        break;
                    case 2:
                        limpaTela();
                        menuGet();
                        std::cin >> menu;
                        getchar();
                        switch (menu)//menu get CONS
                        {
                            case 1:
                                limpaTela();
                                std::cout << "Nome: " << consultor1.getNome() << std::endl;
                                std::cout << "Aperte ENTER.";
                                getchar();
                                break;
                            case 2:
                                limpaTela();
                                std::cout << "Matricula: " << consultor1.getMatricula() << std::endl;
                                std::cout << "Aperte ENTER.";
                                getchar();
                                break;
                            case 3:
                                limpaTela();
                                std::cout << "Salario: R$ " << consultor1.getSalario() << std::endl;
                                std::cout << "Aperte ENTER.";
                                getchar();
                                break;
                            default:
                                limpaTela();
                                std::cout << "Erro, aperte ENTER."; 
                                getchar();
                                break;
                        }
                        break;
                    default:
                        limpaTela();
                        std::cout << "Erro, aperte ENTER."; 
                        getchar();
                        break;
                }
                break;
            case 3:
                limpaTela();
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Erro, aperte ENTER."; 
                getchar();
                break;
        }

    }

    std::cout << "Funcionario1." << std::endl;
    printFuncionario(funcionario1);
    std::cout << "\nConsultor1." << std::endl;
    printConsultor(consultor1);
    std::cout << "\nFim." << std::endl;
    return 0;
}