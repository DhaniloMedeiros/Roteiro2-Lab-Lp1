#pragma once
#include <iostream>

class Funcionario
{
protected:
    std::string matricula;
    std::string nome;
    float salario;
public:
    Funcionario();
    void setMatricula(std::string mt);
    void setNome(std::string n);
    void setSalario(float sl);
    std::string getMatricula();
    std::string getNome();
    float getSalario();
};

