#include "Funcionario.h"
#include <iostream>

Funcionario::Funcionario(){
    nome = "NULL";
    matricula = "NULL";
    salario = 1000;
}
void Funcionario::setMatricula(std::string mt){
    matricula = mt;
}
void Funcionario::setNome(std::string n){
    nome = n;
}
void Funcionario::setSalario(float sl){
    salario = sl;
}
std::string Funcionario::getMatricula(){
    return matricula;
}
std::string Funcionario::getNome(){
    return nome;
}
float Funcionario::getSalario(){
    return salario;
}   
