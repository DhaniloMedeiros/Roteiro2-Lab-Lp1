#pragma once
#include "Funcionario.h"

class Consultor : public Funcionario
{
public:
    float getSalario();
    float getSalario(float percentual);
};
