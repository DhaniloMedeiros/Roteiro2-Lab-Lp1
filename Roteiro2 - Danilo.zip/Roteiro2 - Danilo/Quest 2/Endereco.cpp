#include "Endereco.h"
#include <iostream>

Endereco::Endereco(){
    numero = 0;
    rua = "NULL";
    bairro = "NULL";
    cidade = "NULL";
    estado = "NULL";
    CEP = "NULL";
}
Endereco::Endereco(int n, std::string r, std::string brr, std::string cid, std::string est, std::string cep){
    numero = n;
    rua = r;
    bairro = brr;
    cidade = cid;
    estado = est;
    CEP = cep;
}
std::string Endereco::toString(){
    std::string num = std::to_string(numero);
    std::string address;
    address = "Rua: " + rua + "\nNumero: " + num + "\nBairro: " + bairro;
    address += "\nCidade: " + cidade + "\nEstado: " + estado + "\nCEP: " + CEP;
    return address;
}