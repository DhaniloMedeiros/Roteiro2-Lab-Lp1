#include "Pessoa.h"
#include <iostream>

Pessoa::Pessoa(std::string n){
    nome = n;
    telefone = "NULL";
}
Pessoa::Pessoa(std::string n, Endereco end, std::string tl){
    nome = n;
    endereco = end;
    telefone = tl;
}
std::string Pessoa::getNome(){
    return nome;
}
std::string Pessoa::getTelefone(){
    return telefone;
}
Endereco Pessoa::getEndereco(){
    return endereco;
}
void Pessoa::setNome(std::string n){
    nome = n;
}
void Pessoa::setTelefone(std::string tl){
    telefone = tl;
}
void Pessoa::setEndereco(Endereco end){
    endereco = end;
}