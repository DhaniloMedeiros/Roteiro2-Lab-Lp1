#pragma once
#include "Endereco.h"
#include <iostream>

class Pessoa
{
private:
    std::string nome, telefone;
    Endereco endereco;
public:
    Pessoa(std::string n);
    Pessoa(std::string n, Endereco end, std::string tl);
    std::string getNome();
    std::string getTelefone();
    Endereco getEndereco(); 
    void setNome(std::string n);
    void setTelefone(std::string tl);
    void setEndereco(Endereco end);
};