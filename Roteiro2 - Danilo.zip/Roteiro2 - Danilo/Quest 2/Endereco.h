#pragma once
#include <iostream>

class Endereco
{
public:
    std::string rua, bairro, cidade, estado, CEP;
    int numero;
    Endereco();
    Endereco(int n, std::string r, std::string brr, std::string cid, std::string est, std::string cep);
    std::string toString();
};

