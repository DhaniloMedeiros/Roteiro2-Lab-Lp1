#include <iostream>
#include "Pessoa.h"

void limpaTela(void){
    #ifdef __unix__
        system("clear");
    #elif WIN32
        system("cls");
    #endif
}

void printPessoa(Pessoa &pess){
    Endereco end = pess.getEndereco();
    std::cout << "Nome: " << pess.getNome() << std::endl;
    std::cout << "Telefone: " << pess.getTelefone() << std::endl;
    std::cout << "~~ENDERECO~~\n" << end.toString() << std::endl;
}

void menuSetGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set atributos");
    puts("     2 - Get atributos");
    puts("     3 - Finalizar");

    std::cout << "Digite a opcao desejada:";
}

void menuSet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Set nome");
    puts("     2 - Set telefone");
    puts("     3 - Set endereco");

    std::cout << "Digite a opcao desejada:";
}
void menuGet(){
    puts("\n~~~~~Utilizar Set e Get~~~~~");
    puts("     1 - Get nome");
    puts("     2 - Get telefone");
    puts("     3 - Get endereco");

    std::cout << "Digite a opcao desejada:";
}
int main(){
    Pessoa pessoa1 = Pessoa("Chico Bento");
    Endereco end;
    Pessoa pessoa2 = Pessoa("Ze Lele", end, "4545-4545");
    bool loop = true;
    limpaTela();
    std::cout << "Pessoa1 ->" << std::endl;
    printPessoa(pessoa1);
    std::cout << "\nPessoa2 ->" << std::endl;
    printPessoa(pessoa2);
    std::cout << "\nAperte ENTER pra usar set e get na pessoa1.";
    getchar();

    while(loop){
        int menu, i;
        std::string str;
        limpaTela();
        menuSetGet();
        std::cin >> menu;
        getchar();

        switch(menu){
            case 1:
                limpaTela();
                menuSet();
                std::cin >> menu;
                getchar();
                switch(menu){
                    case 1:
                        limpaTela();
                        std::cout << "Digite o novo nome: ";
                        std::cin >> str;
                        getchar();
                        pessoa1.setNome(str);
                        break;
                    case 2: 
                        limpaTela();
                        std::cout << "Digite o novo telefone: ";
                        std::cin >> str;
                        getchar();
                        pessoa1.setTelefone(str);
                        break;
                    case 3:
                        std::cout << "Digite o numero do endereco: ";
                        std::cin >> i;
                        getchar();
                        end.numero = i;
                        std::cout << "Digite o nome da rua: ";
                        getline(std::cin, str);
                        end.rua = str;
                        std::cout << "Digite o nome do bairro: ";
                        getline(std::cin, str);
                        end.bairro = str;
                        std::cout << "Digite o nome da cidade: ";
                        getline(std::cin, str);
                        end.cidade = str;
                        std::cout << "Digite o nome do estado: ";
                        getline(std::cin, str);
                        end.estado = str;
                        std::cout << "Digite o CEP: ";
                        getline(std::cin, str);
                        end.CEP = str;
                        pessoa1.setEndereco(end);
                        limpaTela();
                        break;
                    default:
                        limpaTela();
                        break;
                }
                break;
            case 2:
                limpaTela();
                menuGet();
                std::cin >> menu;
                getchar();
                switch(menu){
                    case 1:
                        limpaTela();
                        std::cout << "Nome: " << pessoa1.getNome() << std::endl;
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    case 2: 
                        limpaTela();
                        std::cout << "Telefone: " << pessoa1.getTelefone() << std::endl;
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    case 3:
                        limpaTela();
                        end = pessoa1.getEndereco();
                        std::cout << "~~~ENDERECO~~~\n" << end.toString() << std::endl;
                        std::cout << "Aperte ENTER.";
                        getchar();
                        break;
                    default:
                        limpaTela();
                        break;
                }
                break;
            case 3:
                limpaTela();
                loop = false;
                break;
            default:
                limpaTela();
                std::cout << "Erro, aperte ENTER pra voltar ao menu.";
                getchar();
                break;
        }
    }

    std::cout << "Pessoa1 ->" << std::endl;
    printPessoa(pessoa1);
    std::cout << "\nFim" << std::endl;       
    return 0;
}